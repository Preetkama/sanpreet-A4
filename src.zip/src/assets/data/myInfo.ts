import {sanpreet} from '../../app/sanpreet';
export const MYINFO: sanpreet = {
    sid: '991498517',
    sname: 'Preetkamal Kaur', 
    slogin: 'Sanpreet', 
    scampus: 'Davis',
    sproject: 'Assignment #4'
};