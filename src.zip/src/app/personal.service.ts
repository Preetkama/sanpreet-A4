import { Injectable } from '@angular/core';
import {sanpreet} from'./sanpreet';
import {MYINFO} from '../assets/data/myInfo';

@Injectable({
  providedIn: 'root'
})
export class PersonalService {

  constructor() { }
  sanpreet() :sanpreet{
    return MYINFO ;
  }

}
