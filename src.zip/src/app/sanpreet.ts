export class sanpreet {
    sid: string;
    sname: string; 
    slogin: string;
    scampus: string; 
    sproject: string;}
