import { Component,OnInit } from '@angular/core';
import {sanpreet} from './sanpreet';
import{PersonalService} from './personal.service';
import { Breludi } from './breludi';
import breakfast from '../assets/data/Breakfast.json';
import lunch from '../assets/data/Lunch.json';
import dinner from '../assets/data/Dinner.json';
@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent implements OnInit {
  title = 'sanpreet-A4';
  sload:sanpreet;
  breakfastData : Breludi[] = breakfast.breakfast;
  lunchData: Breludi[] = lunch.lunch; 
  dinnerData: Breludi[]= dinner.dinner;

ngOnInit(){
  this.lpLoad();
    }
    constructor(private lService: PersonalService){

    }
    lpLoad():void{
  this.sload = this.lService.sanpreet();
  
    }
  }
