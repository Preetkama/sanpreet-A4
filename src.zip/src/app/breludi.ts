export interface Breludi{
    food: string;
    price: string;
    calories:string;
}
